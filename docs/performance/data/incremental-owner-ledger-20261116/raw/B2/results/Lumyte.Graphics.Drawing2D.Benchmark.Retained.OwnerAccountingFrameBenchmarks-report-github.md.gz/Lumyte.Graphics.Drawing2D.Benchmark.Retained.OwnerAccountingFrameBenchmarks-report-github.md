```

BenchmarkDotNet v0.15.8, Linux Ubuntu 26.04.1 LTS (Resolute Raccoon)
AMD RYZEN AI MAX+ 395 w/ Radeon 8060S 1.66GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host]       : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4
  Core-compare : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=Core-compare  OutlierMode=DontRemove  BuildConfiguration=Release  
Toolchain=.NET 10.0  IterationCount=10  LaunchCount=1  
WarmupCount=3  

```
| Method | StatisticsReads | Dynamic | Mean      | Error     | StdDev    | Median    | Gen0   | Gen1   | Allocated |
|------- |---------------- |-------- |----------:|----------:|----------:|----------:|-------:|-------:|----------:|
| **Frame**  | **0**               | **False**   |  **9.766 μs** | **0.4887 μs** | **0.3232 μs** |  **9.655 μs** | **1.8158** |      **-** |  **29.84 KB** |
| **Frame**  | **0**               | **True**    | **14.052 μs** | **0.3522 μs** | **0.2330 μs** | **14.033 μs** | **2.7008** | **0.1373** |  **44.26 KB** |
| **Frame**  | **1**               | **False**   | **11.303 μs** | **4.9313 μs** | **3.2618 μs** |  **9.716 μs** | **1.8158** |      **-** |  **29.84 KB** |
| **Frame**  | **1**               | **True**    | **13.089 μs** | **0.1480 μs** | **0.0979 μs** | **13.057 μs** | **2.7008** | **0.1373** |  **44.26 KB** |
| **Frame**  | **2**               | **False**   |  **9.040 μs** | **0.2919 μs** | **0.1931 μs** |  **8.947 μs** | **1.8158** |      **-** |  **29.84 KB** |
| **Frame**  | **2**               | **True**    | **13.873 μs** | **1.5783 μs** | **1.0440 μs** | **13.353 μs** | **2.7008** | **0.1373** |  **44.26 KB** |

```

BenchmarkDotNet v0.15.8, Linux Ubuntu 26.04.1 LTS (Resolute Raccoon)
AMD RYZEN AI MAX+ 395 w/ Radeon 8060S 1.66GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host]       : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4
  Core-compare : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=Core-compare  OutlierMode=DontRemove  BuildConfiguration=Release  
Toolchain=.NET 10.0  IterationCount=10  LaunchCount=1  
WarmupCount=3  

```
| Method | NodeCount | Mean     | Error    | StdDev   | Median   | Allocated |
|------- |---------- |---------:|---------:|---------:|---------:|----------:|
| **Read**   | **1**         | **30.36 ns** | **0.115 ns** | **0.076 ns** | **30.33 ns** |         **-** |
| **Read**   | **26**        | **30.52 ns** | **0.543 ns** | **0.359 ns** | **30.38 ns** |         **-** |

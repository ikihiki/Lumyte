```

BenchmarkDotNet v0.15.8, Linux Ubuntu 26.04.1 LTS (Resolute Raccoon)
AMD RYZEN AI MAX+ 395 w/ Radeon 8060S 1.66GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host]       : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4
  Core-compare : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=Core-compare  OutlierMode=DontRemove  BuildConfiguration=Release  
Toolchain=.NET 10.0  IterationCount=10  LaunchCount=1  
WarmupCount=3  

```
| Method | StatisticsReads | Dynamic | Mean      | Error     | StdDev    | Median    | Gen0   | Gen1   | Allocated |
|------- |---------------- |-------- |----------:|----------:|----------:|----------:|-------:|-------:|----------:|
| **Frame**  | **0**               | **False**   |  **9.820 μs** | **0.2253 μs** | **0.1490 μs** |  **9.800 μs** | **2.0599** | **0.0153** |  **33.88 KB** |
| **Frame**  | **0**               | **True**    | **14.830 μs** | **1.1712 μs** | **0.7747 μs** | **14.388 μs** | **2.9907** | **0.1526** |  **49.06 KB** |
| **Frame**  | **1**               | **False**   | **10.198 μs** | **1.0380 μs** | **0.6866 μs** |  **9.903 μs** | **2.1210** |      **-** |  **34.89 KB** |
| **Frame**  | **1**               | **True**    | **14.103 μs** | **0.2404 μs** | **0.1590 μs** | **14.039 μs** | **3.0518** | **0.1526** |  **50.07 KB** |
| **Frame**  | **2**               | **False**   | **11.168 μs** | **0.8089 μs** | **0.5350 μs** | **10.855 μs** | **2.1973** | **0.0153** |  **35.91 KB** |
| **Frame**  | **2**               | **True**    | **15.802 μs** | **0.4443 μs** | **0.2939 μs** | **15.707 μs** | **3.1128** | **0.1526** |  **51.09 KB** |

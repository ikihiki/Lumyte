```

BenchmarkDotNet v0.15.8, Linux Ubuntu 26.04.1 LTS (Resolute Raccoon)
AMD RYZEN AI MAX+ 395 w/ Radeon 8060S 1.67GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host]       : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4
  Core-compare : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=Core-compare  OutlierMode=DontRemove  BuildConfiguration=Release  
Toolchain=.NET 10.0  IterationCount=10  LaunchCount=1  
WarmupCount=3  

```
| Method | StatisticsReads | Dynamic | Mean      | Error     | StdDev    | Median    | Gen0   | Gen1   | Allocated |
|------- |---------------- |-------- |----------:|----------:|----------:|----------:|-------:|-------:|----------:|
| **Frame**  | **0**               | **False**   |  **9.353 μs** | **0.5147 μs** | **0.3405 μs** |  **9.174 μs** | **2.0599** | **0.0153** |  **33.88 KB** |
| **Frame**  | **0**               | **True**    | **20.717 μs** | **8.7041 μs** | **5.7572 μs** | **18.454 μs** | **2.9907** | **0.1526** |  **49.06 KB** |
| **Frame**  | **1**               | **False**   | **12.163 μs** | **3.0071 μs** | **1.9890 μs** | **11.437 μs** | **2.1210** |      **-** |  **34.89 KB** |
| **Frame**  | **1**               | **True**    | **16.241 μs** | **0.2094 μs** | **0.1385 μs** | **16.276 μs** | **3.0518** | **0.1526** |  **50.07 KB** |
| **Frame**  | **2**               | **False**   | **11.200 μs** | **0.9700 μs** | **0.6416 μs** | **11.035 μs** | **2.1973** | **0.0153** |  **35.91 KB** |
| **Frame**  | **2**               | **True**    | **16.881 μs** | **1.0323 μs** | **0.6828 μs** | **17.050 μs** | **3.1128** | **0.1526** |  **51.09 KB** |

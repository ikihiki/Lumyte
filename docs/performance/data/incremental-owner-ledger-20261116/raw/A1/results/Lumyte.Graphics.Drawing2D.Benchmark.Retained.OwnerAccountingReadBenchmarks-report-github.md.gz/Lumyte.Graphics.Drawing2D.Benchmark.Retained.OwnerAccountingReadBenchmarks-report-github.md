```

BenchmarkDotNet v0.15.8, Linux Ubuntu 26.04.1 LTS (Resolute Raccoon)
AMD RYZEN AI MAX+ 395 w/ Radeon 8060S 1.67GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host]       : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4
  Core-compare : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=Core-compare  OutlierMode=DontRemove  BuildConfiguration=Release  
Toolchain=.NET 10.0  IterationCount=10  LaunchCount=1  
WarmupCount=3  

```
| Method | NodeCount | Mean      | Error      | StdDev     | Median    | Gen0   | Allocated |
|------- |---------- |----------:|-----------:|-----------:|----------:|-------:|----------:|
| **Read**   | **1**         |  **50.55 ns** |   **0.187 ns** |   **0.124 ns** |  **50.55 ns** | **0.0024** |      **40 B** |
| **Read**   | **26**        | **846.46 ns** | **546.872 ns** | **361.722 ns** | **642.09 ns** | **0.0620** |    **1040 B** |

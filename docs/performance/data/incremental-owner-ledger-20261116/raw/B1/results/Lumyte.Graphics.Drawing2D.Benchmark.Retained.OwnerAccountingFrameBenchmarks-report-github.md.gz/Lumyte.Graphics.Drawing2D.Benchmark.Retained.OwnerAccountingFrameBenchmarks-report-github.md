```

BenchmarkDotNet v0.15.8, Linux Ubuntu 26.04.1 LTS (Resolute Raccoon)
AMD RYZEN AI MAX+ 395 w/ Radeon 8060S 1.68GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 10.0.403
  [Host]       : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4
  Core-compare : .NET 10.0.14 (10.0.14, 10.0.1426.52326), X64 RyuJIT x86-64-v4

Job=Core-compare  OutlierMode=DontRemove  BuildConfiguration=Release  
Toolchain=.NET 10.0  IterationCount=10  LaunchCount=1  
WarmupCount=3  

```
| Method | StatisticsReads | Dynamic | Mean      | Error     | StdDev    | Median    | Gen0   | Gen1   | Allocated |
|------- |---------------- |-------- |----------:|----------:|----------:|----------:|-------:|-------:|----------:|
| **Frame**  | **0**               | **False**   |  **9.746 μs** | **1.3498 μs** | **0.8928 μs** |  **9.391 μs** | **1.8158** |      **-** |  **29.84 KB** |
| **Frame**  | **0**               | **True**    | **19.332 μs** | **7.0983 μs** | **4.6951 μs** | **17.913 μs** | **2.7008** | **0.1373** |  **44.26 KB** |
| **Frame**  | **1**               | **False**   | **10.686 μs** | **2.2563 μs** | **1.4924 μs** | **10.165 μs** | **1.8158** |      **-** |  **29.84 KB** |
| **Frame**  | **1**               | **True**    | **14.999 μs** | **0.8855 μs** | **0.5857 μs** | **14.763 μs** | **2.7008** | **0.1373** |  **44.26 KB** |
| **Frame**  | **2**               | **False**   | **10.509 μs** | **1.6080 μs** | **1.0636 μs** | **10.429 μs** | **1.8158** |      **-** |  **29.84 KB** |
| **Frame**  | **2**               | **True**    | **13.741 μs** | **0.2002 μs** | **0.1324 μs** | **13.764 μs** | **2.7008** | **0.1373** |  **44.26 KB** |

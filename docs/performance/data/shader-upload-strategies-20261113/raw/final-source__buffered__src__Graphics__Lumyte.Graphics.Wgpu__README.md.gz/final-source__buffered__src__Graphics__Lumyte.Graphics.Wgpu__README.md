# Lumyte.Graphics.Wgpu

[Ahjo.Wgpu](https://www.nuget.org/packages/Ahjo.Wgpu/0.7.0) 0.7.0 を直接使用し、native wgpu のデバイスを生成します。独自の `.Native` プロジェクトは置きません。対象は .NET 10 です。

## 生成と所有権

```csharp
using Lumyte.Graphics.Abstractions;
using Lumyte.Graphics.Wgpu;

using WgpuDevice owner = WgpuDevice.Create();
IGraphicDevice device = owner;
Console.WriteLine(device.Caps.MaxBufferSize);
```

`WgpuDevice.Create()` は同期 API です。instance、default adapter、default limits の logical device を順に生成します。surface は作りません。adapter の探索範囲と native library の配布・ロードは Ahjo.Wgpu に従います。使用可能なドライバーとパッケージの native runtime asset が必要です。

生成に失敗すると取得済みの device、adapter、instance を解放して例外を伝播します。成功後は buffer を先に解放してから所有者が `Dispose()` を呼び、device → adapter → instance の順で解放します。再度の `Dispose()` は何もしません。生成・解放の並行呼び出しはサポートしません。`Caps` は非所有の保存済み情報なので、解放後も読み取れます。

## Caps の対応

生成時に `Device.GetLimits()` を一度呼び、adapter が持つ最大値ではなく、logical device に設定された実効上限を保存します。追加の feature や高い limits は要求しません。

| 共通の値 | 取得元 |
| --- | --- |
| MaxBufferSize | maxBufferSize |
| MaxStorageBufferBindingSize | maxStorageBufferBindingSize |
| MaxTextureDimension2D | maxTextureDimension2D |
| MaxColorAttachments | maxColorAttachments |
| MaxSampledTexturesPerStage | maxSampledTexturesPerShaderStage |
| MaxSamplersPerStage | maxSamplersPerShaderStage |
| MaxUniformBuffersPerStage | maxUniformBuffersPerShaderStage |
| MaxStorageBuffersPerStage | maxStorageBuffersPerShaderStage |
| MaxComputeInvocationsPerWorkgroup | maxComputeInvocationsPerWorkgroup |
| StorageBufferOffsetAlignment | minStorageBufferOffsetAlignment |

GPU buffer copy の offset と length は WebGPU の規定によりそれぞれ 4 byte、encoded buffer-to-texture／texture-to-buffer copy の bytesPerRow は 256 byte alignment です。queue の write 操作や texel block ごとの制約とは区別します。

`IndirectDraw` と `AnisotropicFiltering` は WebGPU の基本機能として返します。`IndirectDraw` は firstInstance が非ゼロの optional feature を保証しません。`DepthBiasClamp` と `MeshShader` は返しません。

このプロジェクトはデバイス生成・解放、Caps 取得と型付き buffer を扱います。[共通契約](../Lumyte.Graphics.Abstractions/README.md) と [native サンプル](../../../samples/Lumyte.Graphics.DeviceCaps.Sample/README.md) を参照してください。

## Buffer

生成済みの `IGraphicDevice` から `CreateBuffer<T>(BufferDesc<T>)` と `GetBufferLayout<T>()` を使用します。Count と SizeInBytes は指定した raw storage のサイズを保ち、alignment のために補正しません。数値型・enum・unmanaged struct は sizeof(T) の stride で格納します。shader target の layout 互換性は別途検証が必要です。

CPU access は `MemoryPreference.Upload` の MapAsync → CopyFrom → Unmap、`Readback` の MapAsync → CopyTo → Unmap で明示します。Automatic は map できません。CopyFrom／CopyTo では map、待機、GPU copy、submit を行いません。GPU copyと同期はcommand bufferへ明示的に記録します。

CPU-mapped buffer は managed byte span で扱える int.MaxValue byte までに制限します。mapping pending 中の再 map・Unmap・Dispose は拒否します。API内部では並列操作を同期しません。bufferとdeviceの解放順、GPU完了とCPU accessの同期は利用者が管理します。親子resource数による解放拒否は行いません。CPU spanの範囲、mapping状態、解放済みinstanceの局所的な検査は維持します。

WebGPU の usage は CopySource → COPY_SRC、CopyDestination → COPY_DST、ShaderRead／ShaderWrite → STORAGE、Index → INDEX に対応します。Upload は CopySource のみと MAP_WRITE、Readback は CopyDestination のみと MAP_READ の組み合わせです。CPU-mapped buffer の size は 4 byte の倍数でなければ生成時に拒否します。GPU-only buffer の論理 size はこの理由で丸めません。

Ahjo の BeginMap と device の ProcessEvents を使い、native callback の完了後に mapping 状態を公開します。キャンセルされても callback の保存先を途中で解放せず、request が完了してから Unmap と cleanup を行います。CPU copy は mapped native span に対して行います。

## TextureとView

生成済みの `IGraphicDevice.CreateTexture(TextureDesc)` から2D imageを確保します。RGBA8／BGRA8のUnorm／sRGB、単一sample、mip／array layer、CopySource／CopyDestination／Sampled／RenderAttachmentを扱います。属性は変更・丸め・暗黙変換しません。capsのMaxTextureDimension2DとMaxTextureArrayLayersを照合し、mip数とusageを検証します。

CreateViewはD2・D2Array・Cube・CubeArrayのsubresourceを選択し、Infoで解決済みのcountを返します。Viewはsourceへの参照を持ちますが、live view／child数の追跡は行いません。利用者がGPU使用の完了を保証し、View、Texture、Deviceの順に解放してください。textureへ自動upload／readbackやGPU待機は追加していません。

Ahjo.WgpuのCreateTexture／CreateViewを直接使用し、native textureとviewを具象resourceが所有します。dimension、format、usage、mip／layer範囲をWebGPU descriptorに明示的に変換します。Disposeではview／textureの参照をReleaseします。native handleを共通APIへ公開しません。

DescとView範囲の検証は、このbackend assembly内のinternalなTextureValidationで行います。Abstractionsの内部型へのアクセスやInternalsVisibleToは使いません。

resource APIは並列実行の安全性を保証しません。内部lockやアトミックな所有カウンターは設けず、backendの実行制約と、生成・CPUコピー・map／unmap・解放の競合に必要な同期を利用者が管理します。GPUでの使用中判定や依存resourceの生存走査は行いません。

## Sampler

CreateSamplerは具象backendのIGraphicsSamplerを返し、Descを変更せずにsampling stateを確保します。enum、有限で非負のLOD、min <= max、正のanisotropyとlinear filter条件をbackend内のSamplerValidationで検証します。caps超過はNotSupportedExceptionで、暗黙補正しません。

Ahjo.Wgpu.NativeのwgpuDeviceCreateSamplerとwgpuSamplerReleaseを直接使用します。Ahjo.WgpuのSamplerDescriptor経由ではLodMaxClamp=0が32へ置換されるため、0固定を保つ目的で同じ.NET bindingのraw descriptorを使用します。新しい.Native projectは追加しません。filters／address／comparisonはnative enumへ明示変換し、anisotropy上限はWebGPUの16です。

samplerはtexture／Viewを所有しません。Disposeは一度だけnative資源を解放し、利用者がsamplerをdeviceより先に解放します。子resource数による解放拒否は行いません。CPU／GPUの利用・解放に必要な同期は利用者の責務です。内部lock、InternalsVisibleTo、sampler cacheは設けません。

## Argument Table

CreateArgumentTableはbackendのIArgumentTableを返し、texture view・sampler・bufferを種類別のDictionaryへ疎に登録します。capacityは論理slotの上限で、巨大な事前確保やshaderのbinding数を意味しません。別tableの同じslotと、種類ごとの同じslotは独立します。Labelは診断用の指定です。

各登録instanceがidentityを持ち、`GpuReference<T>` は同じ登録の型・Count・byte offset／sizeを保持します。GetElementは登録rangeに対するoffsetをchecked計算し、内部Resolveは登録されたresourceとrangeを返します。登録の世代・失効検出は行いません。公開APIへnative handleや整数IDを出しません。

登録resourceは同じdeviceの具象型に限定します。textureはSampled view、bufferはShaderRead／ShaderWrite用途を検証します。登録、派生IGpuRef、記録済みcommandが使用するresourceの寿命は利用者が管理します。置換・Release・table Dispose後の古い参照は使用しないでください。tableは登録resourceをDisposeせず、登録の保持カウンターや失効検出の走査も行いません。同期は利用者の責務で、lock・アトミックカウンター・InternalsVisibleToを使いません。

登録はnative bind groupを生成せず、backendのresource instanceと選択byte rangeを保持します。生成codecとshader binding planがこのidentityと要素metadataを使い、rootから必要なtexture・sampler・bufferを収集して種類別に上限を照合します。物理indexと安定した登録identityを区別し、有限bind groupへの変換をshader／commandへ接続します。

## シェーダーモジュール

共通 API は `IGraphicDevice.CreateShader(ShaderArtifact)` と `IGraphicsShader` です。`Caps.ShaderTarget` は `Wgsl`。Ahjo.Wgpu の `Device.CreateShaderModule` と `ShaderSource.FromWgsl` を直接使用します。WGSL の検証や非同期 device error の扱いは wgpu に従います。shader の `Dispose()` は native module を release します。

artifactのopaque binaryからbackendのtarget codeとmetadataを取得します。同じoffline binaryを全backendへ渡せます。必要targetを含まないonline binaryは`NotSupportedException`で拒否します。shaderと、それを使用するpipeline・commandの生存期間は利用者が管理し、deviceより先に解放します。shader 解放で GPU 完了待機や暗黙の同期は行いません。artifact は GPU module を所有せず、reflection も native API に直接渡しません。pipelineとshader実行命令は別のAPIで扱います。

## CommandBuffer

Ahjo.Wgpuのnative bindingを直接使用してWGPUCommandEncoder／WGPUCommandBufferを保持します。buffer／textureコピーとcolor render・compute passを記録し、Finishでnative recordingを確定します。独自のNativeプロジェクトは追加しません。barrierのstage・access・usageの入力は検査し、textureの状態履歴は記録しません。利用者が状態遷移と依存を指定し、物理的なvisibilityとtexture transitionはWebGPUの順序保証で実現します。

GetTextureCopyLayoutはcolor texel size 4、buffer offset alignment 4、row alignment 256を返します。padding・行の詰め替え・staging確保は行いません。SubmitはQueueSubmitし、BeginOnSubmittedWorkDoneのrequestを保持します。Status／WaitAsyncでProcessEventsを進め、そのrequestの完了を確認します。command bufferと完了requestはGPU使用終了後に利用者が別々にDisposeします。解放時のGPU完了照会は行いません。

共通API、one-shot状態遷移、pass順序、明示的なupload／readbackの手順は [GRAPHICS-0007](../../../docs/adr/graphics/GRAPHICS-0007-command-buffers-and-submission.md) を参照してください。command、submissionとdeviceの解放順は利用者が管理します。記録したresourceの解放、map／unmapとGPUアクセスの同期は利用者の責任です。内部lock・アトミックカウンターや暗黙の完了待機はありません。

## Pipeline

graphics programはshaderの組・topology分類・compile optionを保持し、draw時に描画状態とpassの実attachment formatからnative pipelineを解決します。完全なnative PSOを生成するため、program内でvariantをcacheし、等価なkeyの再利用で生成を繰り返しません。keyにviewport／scissor／blend constant／stencil reference、texture instance、clear値は含めません。variantはprogram Disposeまで保持します。

compute programは作成時にnative pipelineを生成します。programのshader参照とnative variantを保持します。program・shader・commandの有効期間と解放順は利用者が管理し、保持カウンターによる解放拒否やSubmit時の生存再走査は行いません。並列呼び出しの保証、lock、atomic counter、Slang sourceの再compileは追加しません。

reflectionでstage・location・型、vertex pulling入力、workgroup各軸と積を検証します。root-dataとresource helperのABIをartifactから検証し、通常のresource globalを直接受け取るprogramは拒否します。single-sample color/depth/stencil、direct/indexed/indirect draw、direct/indirect compute dispatchを提供します。MSAA・resolve・multi-draw・count bufferは別の拡張です。

Ahjo.Wgpuのnative bindingでWGPURenderPipeline／WGPUComputePipelineを生成します。描画状態は完全なrender pipelineのkeyに入り、dynamic値はrender encoderへ直接設定します。write maskとsample maskはnative descriptorへ正確に渡すため、0をdefaultへ置き換えるwrapperは使いません。root引数のあるprogramは種類別resource集合とroot／remap用bindingから明示layoutを生成します。引数のないprogramはauto layoutを使用します。DepthClipControl等の追加featureは有効化せず、必要なstateは拒否します。

これらの完全なnative pipelineはcacheが必要な生成単位です。dynamic stateはcommandを記録するだけで、一時state objectを生成しません。そのため今回新たに比較対象となる軽量なstate objectはありません。partial programや独立した軽量objectを導入する際は、毎draw生成・状態変更時生成・cacheのCPU時間と保持memoryを同条件で比較し、結果をこのREADMEへ記録します。今回の実装で性能計測済みとは扱いません。

共通契約は [GRAPHICS-0008](../../../docs/adr/graphics/GRAPHICS-0008-pipeline-programs-and-render-state.md)、共通画素検証は [PipelineExercise](../../../samples/Lumyte.Graphics.Shared/PipelineExercise.cs) を参照してください。

## Shader argumentsのbinding容量調整（ADR-0009の設計）

[ADR-GRAPHICS-0009](../../../docs/adr/graphics/GRAPHICS-0009-shader-argument-binding.md)のshader argumentsでは、artifactから取り出したWGSLをbackendが直接調整してからnative shader moduleを生成します。hardwareのlimitsを変更する機能ではなく、有効limitsに収まるresource宣言数とbinding配置を生成する機構です。

compilerはWGSLとともに、変更対象のresource宣言・参照選択helper・binding位置を識別するschemaとABI versionをartifactへ保存します。backendはcompilerが管理する領域を構造的に編集し、resource宣言、binding番号、switch等の参照解決コードを一緒に更新します。定数だけを変えて既存のresource宣言を残す置換や、任意のWGSLへ無条件の正規表現置換を行う方式は使いません。

draw／dispatchで必要な集合を収集し、textureの次元・sample type、sampler種別、buffer用途・accessなどの互換classごとに必要数を求めます。最初は必要数ぴったりの宣言を生成し、0個のclassは宣言を除去します。root uniformと参照変換表の予約枠を含め、全stageのvisibility、種類別limits、group数とgroup内binding数へ照合します。収まらない場合はdraw／dispatchを拒否し、物理上限を超える宣言は生成しません。

resourceを使うprogramのnative moduleとgraphics／compute pipeline variantは、容量が確定するdraw／dispatch時に生成できます。artifact hash、entryとstage集合、helper ABI、容量vector、実binding planをdevice内のcache keyに含めます。同じ容量でも論理型が異なれば別variantです。生成後のWGSLと実binding planを同じ変換結果から作り、artifact内の変換前binding番号を流用しません。

容量調整は数値structのlayoutと安定した参照identityを変えません。sampler共有とtexture数を独立に扱います。textureのsample helperはfragmentのderivative-uniformityを満たすように生成し、非一様な選択では明示gradient等を用いる対応可能な経路かどうか検証します。生成WGSLはDLL内artifactとruntime memoryで扱い、ソース管理へ追加しません。

shader dataはAutomaticのGPU storageとUpload stagingを別々に作ります。CopyFromはmap済みstagingへtarget ABI bytesを書き込み、利用者がunmap、commandのCopyBuffer、barrier、submitを明示します。draw／dispatchはGPU storageを直接bindし、shader dataのuploadや専用backingの生成を行いません。

WGSLだけを含むonline artifactも、このbackendの型schemaとhelper ABIが揃っていればshader data buffer生成へ使用できます。SPIR-V targetがないことだけを理由に拒否しません。全target生成の条件はoffline compilerの成果物に適用します。

## 構造体引数とWGSL binding生成

SetArgumentsは生成transfer実装でC# wire bytes全体と参照identityをsnapshotします。数値はpaddingも含めて無変換でコピーし、参照だけをC#で定義した16-byte slotへ解決します。layout照合はDebug／Releaseとも明示的なvalidation有効時だけ行い、無効時は不一致でもrepackしません。shader dataは明示copyで伝播したreference-only metadataを使って選択要素からIGpuRefを収集します。循環は要素の訪問済み集合で止めます。command内のpartial copyはmetadata overlayを更新し、submit成功後に後続commandへ公開します。

artifactのWGSLを直接編集し、texture・sampler・read-only buffer・writable bufferを独立して重複排除した数だけ宣言します。texture samplingとbuffer wordアクセスのABI-owned helperを生成し、論理slotを種類別の物理bindingへ変換するremapを渡します。root uniformとremap storageも含めて有効limitsを検証し、超過時は描画を分割せずNotSupportedExceptionにします。種類別resource数はprogram内のpipeline variant keyに含めます。

bufferは登録したrangeのoffsetとsizeでbindします。GetElementで作った参照も元の登録rangeを保持し、GPUへ渡す要素offsetはそのrangeの先頭から計算します。同じallocationでも登録rangeが異なれば別bindingとして扱い、同じallocationとrangeの組だけを重複排除します。storage binding sizeの上限はallocation全体ではなく登録rangeへ適用し、binding offsetのalignmentも検証します。

root値とdraw用remapだけをmappedAtCreationで初期化してunmapします。shader dataとraw bufferは確保済みのGPU resourceを直接参照します。stagingのCPU変更はGPU storageを更新しません。利用者がcopyとbarrierを記録し、GPU完了までresourceを保持します。commandはroot／remap backingとbind groupを保持し、Submit時の登録identity・staging revisionの再検証は行いません。参照の有効期間と、copy記録後からGPU完了までのstaging内容の維持は利用者が保証します。

Slang側は`#include "lumyte.slang"`と、`GpuBufferRef<T>`／`GpuRWBufferRef<T>`／GpuTextureRef／GpuSamplerRefを使います。Load／StoreとLumyteSampleGradが対応helperです。最初のsampling helperはfilterableな2D float textureと非comparison samplerを扱い、利用者はschemaの用途に合う参照を渡します。source generatorの導入は[Generators](../Lumyte.Graphics.Generators/README.md)を参照してください。compile時の型schema・buffer参照先型・helper ABI versionはopaque artifactに格納します。

shader dataのstrideと配置はC# unmanaged structのTransferSizeと実際のfield offsetが正本です。pointee reflectionはDebug照合と参照access kindにのみ使用し、数値を再配置しません。root uniformはuint4 wire lanesをshader側でinterpretし、allocation/binding capacityだけを16-byteへ切り上げます。C# wire sizeとoffsetは変更しません。

共有の型配置・参照追跡処理は [Lumyte.Graphics.Shared](../Lumyte.Graphics.Shared/README.md) ライブラリを参照します。バックエンド実装用の契約は Graphics.Abstractions にあり、ソースのリンクコンパイルや InternalsVisibleTo は使用しません。

## Depth／Stencil、Indexed／Indirect実行

`RenderPassDesc.DepthStencilAttachment`へ単一mip・単一layerのD2 viewを指定します。colorは省略でき、depth-only passではfragment shaderのないprogramを使えます。depth/stencilのload/storeは独立で、利用者が`DepthStencilAttachment`へのbarrierを記録します。Depth32Floatはdepthのみ、Depth24Stencil8はdepthと8bit stencilです。今回のdepth textureはRenderAttachment用途に限定し、sampling/copyは生成時に拒否します。

`SetIndexBuffer`はushort／uintのsliceを受け取り、`DrawIndexed`のfirstIndexはsliceからの相対offsetです。stripは`StripIndexFormat`を一致させ、最大index値でprimitive restartします。indexの値はCPUで走査しません。

`DrawIndirect`／`DrawIndexedIndirect`／`DispatchIndirect`はそれぞれ16／20／12byteの1要素sliceをGPU命令として実行します。Indirect usage、4byte alignment、device、記録時の非mapped条件を検査します。Submit時に命令bufferの寿命やmappingを再走査せず、利用者が有効期間を保証します。命令内容はCPUで読み出さず、portable drawのFirstInstance=0、index範囲、workgroup limitsは利用者が守ります。GPU生成後の`ShaderWrite`から`IndirectRead`へのbarrier、転送とsubmitも利用者が明示します。命令bufferの参照とshader root引数は独立で、引数からの資源収集はdirect実行と同じです。

WebGPUのdepth32float／depth24plus-stencil8、render passのdepthStencilAttachment、pipelineのdepthStencil stateを使用します。depth24plus-stencil8のdepth storageはWebGPU実装が決めます。depth formatはpipeline variantのキーへ含めます。setIndexBuffer／drawIndexed／drawIndirect／drawIndexedIndirect／dispatchWorkgroupsIndirectへ直接対応付け、物理的なbarrierはWebGPUのusage管理へ任せます。indirect-first-instance optional featureは要求しません。command bufferが同じpassでwritable storage bindingにも使われる構成はWebGPUのusage競合になるため、生成passと実行passを分け、実行側のrootには必要な資源だけを渡します。

## 追加カラー形式

`R8Unorm`, `Rg8Unorm`, `R16Float`, `Rg16Float`, `Rgba16Float`, `Rgb10A2Unorm`をサンプリング・カラーattachment・コピーへ対応付けます。コピーは形式ごとのtexelサイズを使い、オフセットは4 byteとtexelサイズの両方に整列させます。

WebGPUの標準filterable形式を使い、追加のオプションfeatureは要求しません。

## Surface・Swapchain・Present

`WgpuDevice.Create()`で表示先から独立してadapterとdeviceを生成します。
`device.CreateSurface(source)`は同じdeviceで別targetを受け取ります。利用者が`surface.GetCapabilities()`を照会し、対応する設定を選びます。
`SurfaceSource.WindowsHwnd(hinstance, hwnd)`、`XlibWindow(display, window)`、`WaylandSurface(display, surface)`、`MetalLayer(layer)`、`AndroidNativeWindow(window)`のハンドルは利用側が取得して生存期間を管理します。
このプロジェクトではウインドウを作成せず、OSのハンドル取得APIも呼びません。

ネイティブsurface capabilitiesから形式・usage・present mode・alpha modeを照会し、configure、get-current-texture、surface-presentへ対応します。
wgpuのactive画像は一つです。Present後は以前のframe leaseがGPU使用中でも次の取得を行えますが、再構成は全leaseの解放後に行います。
取得画像はAhjoのtexture参照だけを解放し、通常の所有allocationとして生成・破棄しません。
Native WSIの実ウインドウ接続と実機検証は、ハンドル取得を実装する後続PRで行います。

## 明示的なGPU semaphore

`device.CreateSemaphore()`は単一device queueの発行順序を表すbinary semaphoreを生成します。
WebGPUにはnative semaphoreがないため、同じqueueの順序保証へ対応付けます。
semaphoreのsignal／wait履歴や使用中状態は保持せず、wait／signalリストの検証走査も行いません。stage別のnative待機操作はなく、同期が成立する順序での呼び出しを利用者が保証します。
CPU待機、追加submit、queue idleは挿入しません。commandのないwait／signal Submitも明示的に発行できます。
外部queue・device間の同期や未発行signalへの将来waitは公開しません。使用中のDisposeを検出せず、再利用時点と解放・同期を利用者が管理します。

## 複数ウインドウ

`device.CreateSurfaces(IReadOnlyList<Ahjo.Wgpu.SurfaceSource> sources)`で複数targetを生成済みDeviceへ接続できます。
空リスト、欠けたhandle、同じtargetの重複はnative Surface生成前に拒否します。入力順で返し、途中で失敗した場合は今回生成したSurfaceだけを解放します。Device・Adapter・Instanceと既存Surfaceは保持します。
Surface生成時にcapabilitiesの列挙は行いません。`GetCapabilities()`で選択済みadapterの対応形式などを取得し、対応形式がなければNotSupportedExceptionです。adapterは再選択しません。
単一targetは`device.CreateSurface(source)`で追加できます。

active画像の制約は各Surface／Swapchainに適用し、Device全体を一つのウインドウへ制限しません。
各targetのsize、取得Frame、explicit semaphore、Present、resize、解放は独立しています。同じqueueへまとめてSubmitする場合も、Presentごとのbinary signalを利用側が別々に用意します。
一つのSurfaceの解放は他のSurfaceをunconfigureせず、全Surfaceの解放後に共有Deviceを解放します。

実行時検証の共通方針は[GRAPHICS-0014](../../../docs/adr/graphics/GRAPHICS-0014-caller-managed-resource-validation.md)を参照してください。resourceの保持数、commandからの依存resource走査、subresourceの状態表は検証目的で維持しません。binding生成とshader dataの明示copyに必要な参照収集・metadata伝播は行います。

FrameはGPU submissionを追跡しません。`WaitForReleaseAsync`はこのbackendで追加のGPU待機を行わないため、利用者が`submission.WaitAsync()`等でGPU使用の完了を確認してからFrame・View・commandを解放します。

## デバイスロスト

WgpuDevice.ProcessEventsをEngineのevent loopで定期的に呼んでNative loss callbackを配送します。Status／Lossはcached値です。Ahjo.Wgpu 0.7.0の非公開Device constructorへのアクセスはWgpuDeviceCreationだけに隔離しています。依存更新時はNative生成・lossテストを実行してください。Engineがloss後にWaitForRetirementAsyncでmap／queue callbackの完了を確認してから子資源をDisposeします。backendの子資源操作とDisposeはdevice状態を検証しません。Native status slotはcallback完了前に解放しません。

Status／Lossは診断と上位の制御に使い、backend APIの操作可否を検証しません。loss後はEngineがGPU jobとmappedアクセスを停止してください。新deviceへの生成物の読み替えは行いません。Native並列アクセスの同期は利用側の責任です。

## 非ポーリング完了待機の制約（Ahjo.Wgpu 0.7.0）

現在の WgpuSubmission.WaitAsync、buffer map、WaitForRetirementAsync は
ProcessEvents と 1 ms の再確認を使用します。通知ベースへの変更は未実装です。
タイマーを別 thread に移すだけの変更や、キャンセル時に native callback storage を
解放する変更は行いません。caller のキャンセルは GPU の停止を意味しません。

依存の実装を確認する場合は、NuGet の repository commit
[eda3ed8](https://github.com/pekkah/wgpu-sharp/tree/eda3ed8ca9359b6c9a3fbc2074dcbdceaff179b1)
と、その Directory.Build.props が指定する wgpu-native
[v29.0.0.0](https://github.com/gfx-rs/wgpu-native/tree/v29.0.0.0) を使用します。

- Ahjo の Queue.BeginOnSubmittedWorkDone／Buffer.BeginMap は
  AllowProcessEvents の callback が native status slot を更新する polled request です。
  Task、event、callback の差し替え、future handle の公開はありません。
- raw binding の wgpuInstanceWaitAny は存在しますが、対応する native release の
  src/unimplemented.rs は unimplemented!() です。queue／map request は
  src/lib.rs で NULL_FUTURE を返します。呼び出して capability probe することも
  process abort の危険があるため行いません。
- AllowSpontaneous の指定だけでは GPU の進行通知になりません。この native release の
  queue／map 実装は callback mode を参照せず、wgpu-core の進行処理から callback を呼びます。
- wgpuDevicePoll(device, true, submissionIndex) は本当の blocking primitive ですが、
  同 release の実装は device_poll のエラーを handle_error_fatal に渡します。
  wgpu-core 29.0.1 の Device::maintain は fence wait／fence-value query の device-loss
  エラーを WaitIdleError として返し、native 側は Rust panic を C ABI の外へ返せず abort
  します。managed worker の try/catch、caller cancellation、事前の Status 確認では
  待機開始後の loss race を回避できません。

従ってこの依存版では、device loss を安全に扱う非ポーリング待機への置換は保留です。
上流で実装済み future wait／通知 API、または device-loss error を process abort せず
返す blocking wait が必要です。依存の fork や未対応 API の呼び出しは追加していません。
更新時には concurrent waits、caller cancellation 後の callback retirement、device loss、
submission／device disposal と callback storage の寿命を一緒に再検証してください。

## 任意のmanaged検証

生成した実deviceに、子資源を作る前に`EnableValidation()`を呼ぶと、Debug／Releaseの両方で診断を有効にします。既定ではValidationはnullで、診断tracker・callback・状態走査を作りません。D3D12のnative debug layerとは別設定です。

診断は、記録済み／提出済みresourceの寿命、mapping、登録identityの記録時・Submit時照合、親子関係、byte範囲別buffer hazardとmip／layer別texture状態、shader・index・indirect・copy・attachmentの明示アクセスを扱います。Acquire／Submit／Presentのbinary semaphore履歴とnative完了も追跡します。記録の失敗は診断だけをrollbackし、提出前の照合は複製したqueue状態で行います。nativeが成功した操作だけを公開し、キャンセルされた待機を完了として扱いません。GPU内部の動的indexは登録範囲で保守的に扱い、直接変更したstaging byte、shader内部の実アクセス、外部native操作は見えません。D3D12の部分発行済み操作やWebGPUの非同期実行エラーを巻き戻す保証はありません。検証有効時のdevice操作は外部で直列化し、無効時は寿命・同期とも利用者が保証します。

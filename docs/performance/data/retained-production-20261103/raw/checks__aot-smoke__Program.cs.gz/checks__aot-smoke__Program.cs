using System.Numerics;
using Lumyte.Graphics.Drawing2D;
using Lumyte.UI;
using Widget = Lumyte.UI.Compose.Definitions.Widget;

namespace Lumyte.RetainedAotSmoke;

internal static class Program
{
    private static void Main()
    {
        var cached = new Probe(true);
        var dynamicDrawing = new Probe(false);
        var opaque = new Opaque();
        using var surface = new UiSurface(Lumyte.UI.Compose.Panel()[cached, dynamicDrawing, opaque]);
        surface.SetViewport(new(100, 100));
        using UiDrawingScene2D drawing = surface.CreateDrawingScene();
        drawing.Update();
        drawing.Update();
        if (cached.Runtime.Calls != 1 || dynamicDrawing.Runtime.Calls != 2 || opaque.Runtime.Calls != 2)
        {
            throw new InvalidOperationException("NativeAOT virtual recording classification mismatch.");
        }

        cached.Runtime.Change();
        drawing.Update();
        if (cached.Runtime.Calls != 2 || dynamicDrawing.Runtime.Calls != 3 || opaque.Runtime.Calls != 3)
        {
            throw new InvalidOperationException("NativeAOT invalidation mismatch.");
        }

        using DrawingSnapshot2D snapshot = drawing.Scene.CaptureSnapshot();
        using DrawingSceneReadLease2D read = drawing.Scene.Borrow();
        Console.WriteLine("{\"check\":\"retained-ui-native-aot\",\"status\":\"passed\",\"cachedCalls\":2,\"dynamicCalls\":3,\"opaqueCalls\":3}");
    }

    private sealed class Probe(bool cache) : Widget
    {
        internal bool Cache { get; } = cache;

        internal ProbeElement Runtime { get; private set; } = null!;

        protected override UiElement CreateElement() => Runtime = new(this);
    }

    private sealed class ProbeElement(Probe widget) : UiElement<Probe>(widget)
    {
        internal int Calls { get; private set; }

        protected override bool CacheRetainedDrawing => Widget.Cache;

        internal void Change() => InvalidateDrawing();

        protected override Vector2 LayoutOverride(UiBoxConstraints constraints) => constraints.Constrain(new(10, 10));

        protected override void OnRecord(DrawingCanvas2D canvas)
        {
            Calls++;
            canvas.FillRect(new(0, 0, 5, 5), new Color2D(1, 0, 0, 1));
        }
    }

    private sealed class Opaque : Widget
    {
        internal OpaqueElement Runtime { get; private set; } = null!;

        protected override UiElement CreateElement() => Runtime = new(this);
    }

    private sealed class OpaqueElement(Opaque widget) : UiElement<Opaque>(widget)
    {
        internal int Calls { get; private set; }

        protected override Vector2 LayoutOverride(UiBoxConstraints constraints) => constraints.Constrain(new(10, 10));

        protected override void RecordOverride(DrawingCanvas2D canvas)
        {
            Calls++;
            canvas.FillRect(new(0, 0, 5, 5), new Color2D(0, 1, 0, 1));
        }
    }
}

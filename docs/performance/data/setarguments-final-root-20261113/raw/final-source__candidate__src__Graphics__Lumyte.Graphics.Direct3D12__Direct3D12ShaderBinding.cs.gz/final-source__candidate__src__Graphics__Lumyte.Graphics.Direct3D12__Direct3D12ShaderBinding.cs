using Lumyte.Graphics.Abstractions;

namespace Lumyte.Graphics.Direct3D12;

internal sealed unsafe class Direct3D12ShaderBinding : IDisposable
{
    private nint _native;

    internal Direct3D12ShaderBinding(Direct3D12Device owner, ShaderBindingSnapshot snapshot, ShaderTargetData target)
    {
        ShaderRootArguments root = snapshot.Arguments ?? throw new ArgumentException("Native root arguments are required.", nameof(snapshot));
        root.Seal(value => Direct3D12ShaderReferenceEncoding.Pack(owner, value));
        var storage = (Direct3D12RootStorage)root.Storage;
        owner.Check(NativeMethods.BindingCreateRoot(owner.Native, storage.Native, out _native));

        try
        {
            foreach (IShaderReference reference in snapshot.References)
            {
                switch (reference.Resource)
                {
                    case Direct3D12TextureView view:
                        if (reference.Slot >= 128 || view.Info.Dimension != TextureViewDimension.D2 || view.Info.BaseArrayLayer != 0 || view.Texture.ArrayLayers != 1)
                        {
                            throw new NotSupportedException("The shader helper supports single-layer Texture2D views in slots 0..127.");
                        }

                        NativeMethods.BindingTexture(owner.Native, _native, reference.Slot, view.Native, Direct3D12Texture.NativeFormat(view.Info.Format), 0, view.Info.BaseMipLevel, view.Info.MipLevelCount, 0, 1);
                        break;
                    case Direct3D12Sampler sampler:
                        sampler.ValidateAlive();
                        if (reference.Slot >= 16)
                        {
                            throw new NotSupportedException("Sampler slot exceeds 15.");
                        }

                        SamplerDesc d = sampler.Desc;
                        uint filter = d.MaxAnisotropy > 1 ? 0x55u : (d.MinFilter == FilterMode.Linear ? 0x10u : 0) | (d.MagFilter == FilterMode.Linear ? 4u : 0) | (d.MipmapFilter == FilterMode.Linear ? 1u : 0);
                        if (d.Compare.HasValue)
                        {
                            filter |= 0x80;
                        }

                        NativeMethods.BindingSampler(owner.Native, _native, reference.Slot, filter, Address(d.AddressU), Address(d.AddressV), Address(d.AddressW), d.LodMinClamp, d.LodMaxClamp, d.MaxAnisotropy, d.Compare.HasValue ? (uint)d.Compare.Value + 1 : 8);
                        break;
                    default:
                        if (reference.Slot >= 64)
                        {
                            throw new NotSupportedException("Buffer slot exceeds 63.");
                        }

                        (nint handle, ulong size) = reference.Resource switch
                        {
                            IShaderRawBuffer raw => ((nint)raw.ShaderHandle, raw.SizeInBytes),
                            IShaderDataSource data => ((nint)data.ShaderHandle, data.SizeInBytes),
                            _ => throw new ArgumentException("Unknown buffer reference."),
                        };
                        if (size % 4 != 0)
                        {
                            throw new NotSupportedException("Raw shader storage size must be divisible by four.");
                        }

                        if (reference.BufferAccess == ShaderBufferAccess.ReadOnly)
                        {
                            NativeMethods.BindingBuffer(owner.Native, _native, reference.Slot, handle, size, 0);
                        }

                        if (reference.BufferAccess == ShaderBufferAccess.ReadWrite)
                        {
                            NativeMethods.BindingBuffer(owner.Native, _native, reference.Slot, handle, size, 1);
                        }

                        break;
                }
            }
        }
        catch
        {
            Dispose();
            throw;
        }
    }

    internal nint Native => _native;

    public void Dispose()
    {
        if (_native != 0)
        {
            NativeMethods.BindingDestroy(_native);
        }

        _native = 0;
    }

    private static uint Address(AddressMode mode) => mode switch { AddressMode.Repeat => 1, AddressMode.MirrorRepeat => 2, AddressMode.ClampToEdge => 3, _ => throw new ArgumentException("Unknown address mode.") };
}
